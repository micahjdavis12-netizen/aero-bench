AeroBench Connect 0.3.0

Keep the full AeroBench.app installed in Applications. Put this small Connect app alongside it and use Connect to open the wind tunnel.

Connect downloads checksum-verified code from micahjdavis12-netizen/aero-bench on GitHub and reuses your existing solver and runtime. It does not publish scans or results. Private models, runs and keys remain on your Mac. The public site loads them through a private paired connection.

This preview has ad-hoc integrity signatures, not Apple notarization. macOS may require app-specific Open Anyway approval. Native launch still needs testing on your Mac. Updates from this repository are executable code; protect write access to your GitHub account.
